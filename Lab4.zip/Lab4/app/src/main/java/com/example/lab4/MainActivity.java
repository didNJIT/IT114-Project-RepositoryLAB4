package com.example.lab4;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.view.SimpleDraweeView;

public class MainActivity extends AppCompatActivity {

    private EditText urlInput;
    private SimpleDraweeView imageArea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Fresco must be initialized BEFORE setContentView(),
        // otherwise inflating the SimpleDraweeView will crash.
        Fresco.initialize(this);

        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.url_input);
        imageArea = findViewById(R.id.image_area);
        Button displayButton = findViewById(R.id.display_button);

        displayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayImage();
            }
        });
    }

    private void displayImage() {
        String url = urlInput.getText().toString().trim();

        if (url.isEmpty()) {
            Toast.makeText(this, "Please enter a URL", Toast.LENGTH_SHORT).show();
            return;
        }

        // Unlike Lab #2, no background thread is needed here:
        // Fresco downloads and decodes the image off the UI thread for you.
        Uri imageUri = Uri.parse(url);
        imageArea.setImageURI(imageUri);
    }
}